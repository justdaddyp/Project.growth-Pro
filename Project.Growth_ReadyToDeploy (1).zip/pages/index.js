export default function Home() {
  return (
    <main>
      <h1>Welcome to Project.Growth 🚀</h1>
      <p>This is the beginning of a new era for Gen Z intellectual charisma.</p>
    </main>
  );
}