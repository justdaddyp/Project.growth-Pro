# Project.Growth

> Where Gen Z charisma meets intellectual grit. Built for expansion, with both frontend charm and backend power.

## Scripts

```bash
npm install
npm run dev
```

Then deploy to Vercel.